
let jogador; // Objeto principal controlado pelo jogador
let itens = []; // Lista de itens colecionáveis
let inimigos = []; // Lista de inimigos que o jogador deve evitar
let plataformas = []; // Lista de plataformas no jogo
let pontos = 0; // Pontuação do jogador
let tempo = 60;  // Tempo total de jogo (em segundos)
let gravidade = 0.8; // Força da gravidade aplicada ao jogador
let velocidadePulo = -15; // Velocidade vertical do pulo
let plataformaAltura = 20; // Altura das plataformas
let jogoFim = false; // Indica se o jogo terminou
let tempoInicial; // Momento em que o jogo começou

function setup() {
  createCanvas(600, 400); // Define o tamanho da tela do jogo
  jogador = new Jogador(width / 2, height - 50); // Cria o jogador no centro da tela

  plataformas.push(new Plataforma(0, height - 40, width, plataformaAltura)); // Cria uma plataforma de chão

  for (let i = 0; i < 5; i++) { // Cria 5 itens e 5 inimigos iniciais
    criarItem(); // Adiciona item aleatório à lista
    criarInimigo(); // Adiciona inimigo aleatório à lista
  }

  textSize(20); // Define o tamanho do texto padrão
  tempoInicial = millis(); // Armazena o tempo inicial do jogo
}

function draw() {
  background(200); // Define o fundo cinza claro

  if (jogoFim) { // Verifica se o jogo acabou
    mostrarFimDeJogo(); // Mostra a tela de fim de jogo
    return; // Para de desenhar o restante
  }

  let tempoRestante = tempo - int((millis() - tempoInicial) / 1000); // Calcula o tempo restante
  if (tempoRestante <= 0) { // Se o tempo acabar
    jogoFim = true; // Marca o jogo como finalizado
    mostrarFimDeJogo(); // Exibe a tela de fim
    return;
  }

  jogador.atualizar(); // Atualiza posição e lógica do jogador
  jogador.mostrar(); // Desenha o jogador

  for (let plataforma of plataformas) { // Para cada plataforma
    plataforma.mostrar(); // Desenha a plataforma
  }

  for (let i = itens.length - 1; i >= 0; i--) { // Percorre os itens de trás para frente
    let item = itens[i]; // Pega o item atual
    item.mostrar(); // Desenha o item
    if (jogador.colidirComItem(item)) { // Se o jogador colide com o item
      pontos++; // Aumenta a pontuação
      itens.splice(i, 1); // Remove o item da lista
    }
  }

  for (let i = inimigos.length - 1; i >= 0; i--) { // Percorre os inimigos de trás para frente
    let inimigo = inimigos[i]; // Pega o inimigo atual
    inimigo.mover(); // Move o inimigo
    inimigo.mostrar(); // Desenha o inimigo
    if (jogador.colidirComInimigo(inimigo)) { // Se colidir com inimigo
      pontos -= 5; // Diminui 5 pontos
      inimigos.splice(i, 1); // Remove o inimigo da lista
    }
  }

  if (jogador.pos.x > width - 50) { // Se o jogador chega ao lado direito da tela
    jogoFim = true; // Termina o jogo
  }

  fill(0); // Cor preta para o texto
  text(`Pontos: ${pontos}`, 10, 30); // Mostra a pontuação
  text(`Tempo: ${tempoRestante}s`, 10, 60); // Mostra o tempo restante
}

// Classe do jogador
class Jogador {
  constructor(x, y) {
    this.pos = createVector(x, y); // Posição inicial do jogador
    this.vel = createVector(0, 0); // Velocidade inicial
    this.largura = 40; // Largura do jogador
    this.altura = 40; // Altura do jogador
    this.pulando = false; // Indica se o jogador está pulando
  }

  atualizar() {
    this.vel.y += gravidade; // Aplica gravidade ao jogador

    if (keyIsDown(LEFT_ARROW)) this.pos.x -= 5; // Move para esquerda
    if (keyIsDown(RIGHT_ARROW)) this.pos.x += 5; // Move para direita

    if (keyIsDown(UP_ARROW) && !this.pulando) { // Pula se não estiver no ar
      this.vel.y = velocidadePulo; // Aplica velocidade de pulo
      this.pulando = true; // Marca como pulando
    }

    this.pos.add(this.vel); // Atualiza a posição com a velocidade

    for (let plataforma of plataformas) { // Verifica colisão com plataformas
      if (this.colidirComPlataforma(plataforma)) {
        this.pulando = false; // Permite pular novamente
        this.vel.y = 0; // Para a queda
        this.pos.y = plataforma.pos.y - this.altura; // Ajusta posição sobre a plataforma
      }
    }

    this.pos.x = constrain(this.pos.x, 0, width - this.largura); // Limita posição horizontal
    this.pos.y = constrain(this.pos.y, 0, height - this.altura); // Limita posição vertical
  }

  mostrar() {
    fill(0, 0, 255); // Cor azul
    rect(this.pos.x, this.pos.y, this.largura, this.altura); // Desenha o jogador como um retângulo
  }

  colidirComPlataforma(plataforma) {
    let emCima = this.pos.y + this.altura <= plataforma.pos.y; // Verifica se está acima
    let descendo = this.pos.y + this.altura + this.vel.y >= plataforma.pos.y; // Se está caindo sobre a plataforma
    let dentroHorizontal = this.pos.x + this.largura > plataforma.pos.x &&
                           this.pos.x < plataforma.pos.x + plataforma.largura; // Verifica sobreposição horizontal
    return emCima && descendo && dentroHorizontal; // Retorna se há colisão
  }

  colidirComItem(item) {
    return dist(this.pos.x, this.pos.y, item.pos.x, item.pos.y) < 30; // Verifica colisão por distância
  }

  colidirComInimigo(inimigo) {
    return dist(this.pos.x, this.pos.y, inimigo.pos.x, inimigo.pos.y) < 30; // Verifica colisão com inimigo
  }
}

// Classe Plataforma
class Plataforma {
  constructor(x, y, largura, altura) {
    this.pos = createVector(x, y); // Posição da plataforma
    this.largura = largura; // Largura da plataforma
    this.altura = altura; // Altura da plataforma
  }

  mostrar() {
    fill(0, 255, 0); // Cor verde
    rect(this.pos.x, this.pos.y, this.largura, this.altura); // Desenha a plataforma
  }
}

// Classe Item
class Item {
  constructor(x, y) {
    this.pos = createVector(x, y); // Posição do item
    this.tipo = random(["🌽", "🚜", "🐄", "🏙️", "🚗", "🏢"]); // Ícone aleatório para representar o item
  }

  mostrar() {
    textSize(24); // Tamanho do emoji
    text(this.tipo, this.pos.x, this.pos.y); // Desenha o emoji do item
  }
}

// Classe Inimigo
class Inimigo {
  constructor(x, y) {
    this.pos = createVector(x, y); // Posição do inimigo
    this.velocidade = random(2, 3); // Velocidade de movimento do inimigo
  }

  mover() {
    this.pos.x -= this.velocidade; // Move o inimigo para a esquerda
  }

  mostrar() {
    fill(255, 0, 0); // Cor vermelha
    ellipse(this.pos.x, this.pos.y, 30); // Desenha o inimigo como um círculo
  }
}

// Criar item aleatório
function criarItem() {
  let x = random(width); // Posição horizontal aleatória
  let y = random(100, height - 60); // Posição vertical aleatória
  itens.push(new Item(x, y)); // Adiciona o item à lista
}

// Criar inimigo aleatório
function criarInimigo() {
  let x = random(width, width + 200); // Começa fora da tela
  let y = random(50, height - 150); // Posição vertical aleatória
  inimigos.push(new Inimigo(x, y)); // Adiciona o inimigo à lista
}

// Mostrar tela de fim de jogo
function mostrarFimDeJogo() {
  background(50, 0, 0); // Fundo vermelho escuro
  textAlign(CENTER); // Alinha o texto ao centro
  textSize(32); // Tamanho do texto
  fill(255); // Cor branca
  text("Fim de Jogo!", width / 2, height / 2 - 20); // Mensagem de fim
  text(`Sua pontuação final: ${pontos}`, width / 2, height / 2 + 20); // Exibe a pontuação final
}
